package com.example.MedicalAppointment.entity;

public enum TokenStatus {
    WAITING,
    SERVED
}