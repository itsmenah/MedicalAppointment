package com.example.MedicalAppointment.entity;

public enum Role {
    PATIENT,
    DOCTOR,
    ADMIN
}