package com.example.MedicalAppointment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalAppointmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalAppointmentApplication.class, args);
	}

}
