package com.example.MedicalAppointment.entity;

public enum Status {
    BOOKED,
    CANCELLED,
    DONE
}