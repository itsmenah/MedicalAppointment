package com.example.MedicalAppointment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalAppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
